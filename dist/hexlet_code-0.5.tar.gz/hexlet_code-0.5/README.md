### Hexlet tests and linter status:
[![Actions Status](https://github.com/arisesinmight/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/arisesinmight/python-project-50/actions)

[![pytest](https://github.com/arisesinmight/python-project-50/actions/workflows/action.yml/badge.svg)](https://github.com/arisesinmight/python-project-50/actions/workflows/action.yml)

[![Maintainability](https://api.codeclimate.com/v1/badges/033478317ad126c5eb2a/maintainability)](https://codeclimate.com/github/arisesinmight/python-project-50/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/033478317ad126c5eb2a/test_coverage)](https://codeclimate.com/github/arisesinmight/python-project-50/test_coverage)

[![asciicast](https://asciinema.org/a/eXvmH8GhkdPxUuhWlTUnjcy5Q.svg)](https://asciinema.org/a/eXvmH8GhkdPxUuhWlTUnjcy5Q)(https://asciinema.org/a/I7yX0FggbwMVxWU5B38FeWD20.svg)](https://asciinema.org/a/I7yX0FggbwMVxWU5B38FeWD20)

[![asciicast](https://asciinema.org/a/qrdp05HPdLXp2USyAZZqszUpQ.svg)](https://asciinema.org/a/qrdp05HPdLXp2USyAZZqszUpQ)